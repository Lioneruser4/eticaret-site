import os
import logging
import sqlite3
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
    CallbackQueryHandler
)
import yt_dlp

# Logger ayarları
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# FFmpeg yolunu ayarla
os.environ["PATH"] += os.pathsep + "/app/.heroku/vendor/bin"

# Dil ayarları
LANGUAGES = {
    "en": "Hello! Send me an Instagram or TikTok link to download the video.",
    "tr": "Merhaba! Instagram veya TikTok linki göndererek video indirebilirsiniz.",
    "az": "Salam! Instagram və ya TikTok linki göndərərək video yükləyə bilərsiniz.",
}
DEFAULT_LANG = "az"

# Bayrak simgeleri
FLAGS = {
    "en": "🇬🇧",
    "tr": "🇹🇷",
    "az": "🇦🇿",
}

# SQLite veritabanı işlemleri
def create_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    chat_id INTEGER PRIMARY KEY, 
                    lang TEXT)''')
    conn.commit()
    conn.close()

def add_user(chat_id, lang=DEFAULT_LANG):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('INSERT OR IGNORE INTO users (chat_id, lang) VALUES (?, ?)', (chat_id, lang))
    conn.commit()
    conn.close()

def get_users():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('SELECT chat_id FROM users')
    users = c.fetchall()
    conn.close()
    return [user[0] for user in users]

def get_user_count():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM users')
    count = c.fetchone()[0]
    conn.close()
    return count

# Admin ID'leri belirleyin
ADMIN_IDS = [976640409]  # Adminlerin chat_id'lerini buraya ekleyin

# Komutlar
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_lang = context.user_data.get("lang", DEFAULT_LANG)
    chat_id = update.message.chat_id

    # Kullanıcıyı veritabanına kaydet
    add_user(chat_id, user_lang)
    
    # Dil seçim butonları ve bayrak simgeleri
    keyboard = [
        [InlineKeyboardButton(f"{FLAGS['en']} English", callback_data="en")],
        [InlineKeyboardButton(f"{FLAGS['tr']} Türkçe", callback_data="tr")],
        [InlineKeyboardButton(f"{FLAGS['az']} Azərbaycanca", callback_data="az")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Mesaj gönder
    await update.message.reply_text(
        LANGUAGES[user_lang],
        reply_markup=reply_markup,
    )

# Dil değişikliği işlevi
async def lang(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_lang = query.data

    # Dil veritabanını güncelle
    chat_id = query.message.chat.id
    add_user(chat_id, user_lang)

    # Kullanıcıya dilin başarıyla değiştiği mesajını gönder
    await query.answer()  # Yanıt ver
    await query.edit_message_text(
        text=f"Dil başarıyla {user_lang} olarak ayarlandı.",
        reply_markup=None,
    )

    # Yeni dilde mesaj gönder
    await query.message.reply_text(LANGUAGES[user_lang])

# Video indirme fonksiyonu
async def download_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = update.message.text
    chat_id = update.message.chat_id
    user_lang = context.user_data.get("lang", DEFAULT_LANG)

    # Sadece TikTok ve Instagram linklerini kabul et
    if not ("instagram.com" in url or "tiktok.com" in url):
        return  # Herhangi bir link değilse yanıt verme

    # "🚀" mesajı gönder
    download_message = await update.message.reply_text("🚀")

    # Geçici dosya yolları
    video_path = f"/tmp/{chat_id}_video.mp4"
    audio_path = f"/tmp/{chat_id}_audio.mp4"
    final_path = f"/tmp/{chat_id}_final.mp4"

    # Instagram video ve ses indirme
    if "instagram.com" in url:
        ydl_opts_video = {
            "outtmpl": video_path,
            "format": "bestvideo",
            "noplaylist": True,
            "merge_output_format": "mp4",
        }

        ydl_opts_audio = {
            "outtmpl": audio_path,
            "format": "bestaudio",
            "noplaylist": True,
        }

        try:
            # Video ve ses akışlarını ayrı ayrı indir
            with yt_dlp.YoutubeDL(ydl_opts_video) as ydl:
                ydl.download([url])

            with yt_dlp.YoutubeDL(ydl_opts_audio) as ydl:
                ydl.download([url])

            # FFmpeg ile ses ve videoyu birleştir
            os.system(
                f"ffmpeg -i \"{video_path}\" -i \"{audio_path}\" -c:v copy -c:a aac -strict experimental \"{final_path}\" -y"
            )

            # Telegram'a gönder, açıklamaya @allsvbot ekle
            video_message = await update.message.reply_video(
                video=open(final_path, "rb"),
                caption="@allsvbot"
            )

            # İkinci mesaj ve butonlar
            keyboard = [
                [
                    InlineKeyboardButton("🖼️ Stickerlər və dahası 💲", url="https://t.me/xaliqq"),
                    InlineKeyboardButton("🎧 Musiqi Kanalımız 🎧", url="https://t.me/btmusiqi"),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await video_message.reply_text("Yükləndi 📥", reply_markup=reply_markup)

            # Geçici dosyaları temizle
            os.remove(video_path)
            os.remove(audio_path)
            os.remove(final_path)

            # "🚀" mesajını sil
            await download_message.delete()

        except Exception as e:
            logger.error(f"Error: {e}")
            await update.message.reply_text("🚀")

    # TikTok video indirme
    elif "tiktok.com" in url:
        ydl_opts = {
            "outtmpl": video_path,
            "format": "bestvideo+bestaudio/best",
            "noplaylist": True,
            "merge_output_format": "mp4",
            "postprocessors": [{
                "key": "FFmpegVideoConvertor",
                "preferedformat": "mp4",
            }],
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])

            # Telegram'a gönder, açıklamaya @allsvbot ekle
            video_message = await update.message.reply_video(
                video=open(video_path, "rb"),
                caption="@allsvbot"
            )

            # İkinci mesaj ve butonlar
            keyboard = [
                [
                    InlineKeyboardButton("🖼️ Stickerlər və dahası 💲", url="https://t.me/xaliqq"),
                    InlineKeyboardButton("🎧 Musiqi Kanalımız 🎧", url="https://t.me/btmusiqi"),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await video_message.reply_text("Yükləndi 📥", reply_markup=reply_markup)

            # Geçici dosyaları temizle
            os.remove(video_path)

            # "🚀" mesajını sil
            await download_message.delete()

        except Exception as e:
            logger.error(f"Error: {e}")
            await update.message.reply_text("🚀")

# Stats komutu (sadece adminlere)
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message.chat_id not in ADMIN_IDS:
        return  # Admin olmayan kullanıcıya yanıt verme

    user_count = get_user_count()  # Veritabanından kullanıcı sayısını al
    await update.message.reply_text(f"Toplam kullanıcı sayısı: {user_count}")

# Broadcast komutu (sadece adminlere) - bcast özelliği eklendi
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message.chat_id not in ADMIN_IDS:
        return  # Admin olmayan kullanıcıya yanıt verme

    if update.message.text.startswith("/bcast"):  # Mesaj "/bcast" ile başlamalı
        message = update.message.text[6:].strip()  # "/bcast" kısmından sonrasını al
        if not message:
            await update.message.reply_text("Yayın mesajını belirtmediniz.")  # Mesaj verilmemişse kullanıcıya hatırlatma yap
            return

        users = get_users()  # Kullanıcıları veritabanından al
        for user in users:
            try:
                await context.bot.send_message(user, message)  # Her kullanıcıya mesaj gönder
            except Exception as e:
                logger.error(f"Error sending message to {user}: {e}")

        await update.message.reply_text("Yayın mesajı tüm kullanıcılara gönderildi.")

# Uygulama oluşturma ve komutları ekleme
def run_bot():
    application = ApplicationBuilder().token("7000832673:AAEkJ_1XMWz1ODPdiwqs_I_h0915rLCjPKA").build()

    # Komutlar ve handler'lar
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(lang))
    application.add_handler(CommandHandler("stats", stats))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, download_video))
    application.add_handler(CommandHandler("bcast", broadcast))

    application.run_polling()

# Ana fonksiyonu çalıştır
if __name__ == "__main__":
    create_db()  # Veritabanını oluştur
    run_bot()
